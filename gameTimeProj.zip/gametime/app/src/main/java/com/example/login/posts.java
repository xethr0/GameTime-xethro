package com.example.login;

public class posts {
    String eventLocation;
    String eventTitle;
    String description;
    String postUsername;
    String datePosted;
    String timePosted;
    String eventDate;
    String eventTime;

    public posts(String eventLocation, String eventTitle, String description, String postUsername, String datePosted, String timePosted, String eventDate, String eventTime) {
        this.eventLocation = eventLocation;
        this.eventTitle = eventTitle;
        this.description = description;
        this.postUsername = postUsername;
        this.datePosted = datePosted;
        this.timePosted = timePosted;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
    }

    public posts() {
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPostUsername() {
        return postUsername;
    }

    public void setPostUsername(String postUsername) {
        this.postUsername = postUsername;
    }

    public String getDatePosted() {
        return datePosted;
    }

    public void setDatePosted(String datePosted) {
        this.datePosted = datePosted;
    }

    public String getTimePosted() {
        return timePosted;
    }

    public void setTimePosted(String timePosted) {
        this.timePosted = timePosted;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }
}
